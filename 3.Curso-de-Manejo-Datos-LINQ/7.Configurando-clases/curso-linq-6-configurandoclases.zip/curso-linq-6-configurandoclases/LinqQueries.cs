public class LinqQueries
{
    public LinqQueries()
    {
        
    }
}